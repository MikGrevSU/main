from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('profile/', views.profile_view, name='profile_view'),  # Переназначили профиль на /profile/
    path('profile/update-photo/', views.update_profile_photo, name='update_profile_photo'),
    path('profile/update-address/', views.update_address, name='update_address'),
    path('logout/', views.logout_view, name='logout'),
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('change-password/', views.change_password, name='change_password'),
    path('order_success/', views.order_success, name='order_success'),
    path('remove_from_cart/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('submit-review/<int:product_id>/', views.submit_review, name='submit_review'),
    path('like-review/<int:review_id>/', views.like_review, name='like_review'),
    path('product/<int:pk>/', views.product_detail, name='product_detail'),
    # Новые страницы
    path('terms-of-service/', views.terms_of_service, name='terms_of_service'),
    path('return-policy/', views.return_policy, name='return_policy'),
    path('contacts/', views.contacts, name='contacts'),
    path('about-us/', views.about_us, name='about_us'),
]

