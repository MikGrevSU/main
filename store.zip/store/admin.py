from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from .models import Profile
from .models import Product
from django.utils.html import format_html
from .models import Order



@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number')  
    search_fields = ('user__username', 'phone_number')  
    list_filter = ('user__is_active', 'user__is_staff') 

admin.site.unregister(User)
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'is_staff', 'is_superuser', 'date_joined')
    search_fields = ('username', 'email')
    list_filter = ('is_staff', 'is_superuser', 'is_active')

    
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'photo')  
    search_fields = ('name', 'description')
    list_filter = ('price',)  
    ordering = ('price',) 

    def image_preview(self, obj):
        if obj.photo:
            return format_html('<img src="{}" width="50" height="50" />', obj.photo.url)
        return "-"
    image_preview.short_description = 'Фото'


    fieldsets = (
        (None, {
            'fields': ('name', 'description', 'price', 'photo')
        }),
    )


class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'status', 'created_at', 'total_price')
    list_filter = ('status',)
    search_fields = ('user__username', 'status')
    list_editable = ('status',)

admin.site.register(Order, OrderAdmin)

admin.site.site_header = "Административная панель Eshop"
admin.site.site_title = "Eshop Admin"
admin.site.index_title = "Добро пожаловать в админку"
