from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from .forms import CustomUserCreationForm, UserProfileForm, CustomPasswordChangeForm
from .models import Product, Cart, UserProfile 
from django.contrib.auth import update_session_auth_hash
from django.core.exceptions import ObjectDoesNotExist
from .models import Order
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.forms import PasswordChangeForm
from django.http import JsonResponse
from .models import ProductReview
import logging
logger = logging.getLogger(__name__)


# Главная страница
def index(request):
    products = Product.objects.all()
    return render(request, 'store/index.html', {'products': products})

# Регистрация
def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(user=user) 
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'store/register.html', {'form': form})

# Авторизация
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('index')


@login_required
def update_profile_photo(request):
    try:
        user_profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        user_profile = UserProfile(user=request.user)
        user_profile.save()

    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('profile') 
    else:
        form = UserProfileForm(instance=user_profile)
    
    return render(request, 'store/profile.html', {'form': form})

# Изменение парол
@csrf_protect
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            messages.success(request, 'Пароль успешно изменен!')
            return redirect('profile') 
        else:
            messages.error(request, 'Ошибка изменения пароля. Пожалуйста, попробуйте снова.')
    else:
        form = PasswordChangeForm(user=request.user)
    
    return render(request, 'store/change_password.html', {'form': form})

@login_required
def update_address(request):
    user_profile = UserProfile.objects.get(user=request.user)
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('profile')  
    else:
        form = UserProfileForm(instance=user_profile)
    
    return render(request, 'store/profile.html', {'form': form})

# Добавить в корзину
@login_required
def add_to_cart(request, product_id):
    try:
        product = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return redirect('index')

    cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('index')

# Корзина
@login_required
def cart(request):
    cart_items = Cart.objects.filter(user=request.user)
    total_price = sum(item.total_price for item in cart_items)
    return render(request, 'store/cart.html', {'cart_items': cart_items, 'total_price': total_price})

# Удалить из корзины
@login_required
def remove_from_cart(request, cart_item_id):
    try:
        cart_item = Cart.objects.get(id=cart_item_id, user=request.user)  # Убедитесь, что корзина принадлежит текущему пользователю
        if cart_item.quantity > 1:
            cart_item.quantity -= 1  # Уменьшаем количество на 1
            cart_item.save()
        else:
            cart_item.delete()  # Удаляем объект, если количество равно 1
    except Cart.DoesNotExist:
        pass  # Если элемент не найден, ничего не делаем
    return redirect('cart')  # Перенаправляем на страницу корзины

@login_required
def checkout(request):
    cart_items = Cart.objects.filter(user=request.user)
    total_price = sum(item.total_price for item in cart_items)

    if request.method == 'POST':
        
        missing_fields = [field for field in ['name', 'phone', 'address', 'payment_method'] if not request.POST.get(field)]
        if missing_fields:
            error_message = f"Не заполнены обязательные поля: {', '.join(missing_fields)}."
            return render(request, 'store/checkout.html', {
                'cart_items': cart_items, 
                'total_price': total_price, 
                'error': error_message
            })

        if not cart_items:
            return render(request, 'store/checkout.html', {
                'error': 'Ваша корзина пуста', 
                'cart_items': cart_items, 
                'total_price': total_price
            })

        try:
            order = Order(
                user=request.user,
                name=request.POST['name'],
                phone=request.POST['phone'],
                address=request.POST['address'],
                payment_method=request.POST['payment_method'],
                comment=request.POST.get('comment', ''),
                total_price=total_price
            )
            order.save()
            logger.info(f"Order created successfully: {order}")
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            return render(request, 'store/checkout.html', {
                'cart_items': cart_items,
                'total_price': total_price,
                'error': 'Ошибка при создании заказа.'
        })
        # Очистка корзины
        cart_items.delete()
        return redirect('order_success') 

    return render(request, 'store/checkout.html', {
        'cart_items': cart_items, 
        'total_price': total_price
    })


@login_required
def profile_view(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)

    # Получение заказов пользователя
    orders = Order.objects.filter(user=request.user).order_by('-created_at')

    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = UserProfileForm(instance=user_profile)

    # Отправляем как форму, так и заказы в шаблон
    return render(request, 'store/profile.html', {'form': form, 'user_profile': user_profile, 'orders': orders})






def order_success(request):
    return render(request, 'store/order_success.html')



def terms_of_service(request):
    return render(request, 'store/terms_of_service.html')

def return_policy(request):
    return render(request, 'store/return_policy.html')

def contacts(request):
    return render(request, 'store/contacts.html')

def about_us(request):
    return render(request, 'store/about_us.html')


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    reviews = product.reviews.all()  # Получаем все отзывы, связанные с продуктом
    return render(request, 'store/product.html', {'product': product, 'reviews': reviews})


def submit_review(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    if request.method == "POST":
        name = request.POST.get("name")
        review = request.POST.get("review")
        rating = request.POST.get("rating")

        # Проверка, чтобы убедиться, что product_id передается корректно
        print(f"Product ID: {product_id}")
        print(f"Review data: Name={name}, Review={review}, Rating={rating}")

        ProductReview.objects.create(
            name=name,
            review=review,
            rating=rating,
            product=product
        )

        return redirect('product_detail', pk=product.id)

def like_review(request, review_id):
    if request.method == "POST":
        review = ProductReview.objects.get(pk=review_id)
        review.likes += 1
        review.save()
        return JsonResponse({"success": True, "likes": review.likes})

    return JsonResponse({"success": False})

